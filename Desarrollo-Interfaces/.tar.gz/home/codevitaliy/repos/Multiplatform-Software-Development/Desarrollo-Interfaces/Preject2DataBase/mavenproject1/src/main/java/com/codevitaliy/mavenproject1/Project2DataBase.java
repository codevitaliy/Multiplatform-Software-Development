/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.codevitaliy.mavenproject1;

/**
 *
 * @author codevitaliy
 */
public class Project2DataBase {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
